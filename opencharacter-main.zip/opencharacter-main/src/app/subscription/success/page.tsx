export const runtime = 'edge';

export default function Success() {
    return (
        <div>
            <h1>Success</h1>
            <p>Your subscription has been successfully created.</p>
        </div>
    )
}