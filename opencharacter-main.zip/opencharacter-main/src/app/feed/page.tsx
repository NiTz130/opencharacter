export const runtime = 'edge';

export default function FeedPage() {
    return (
        <div className="text-center">
           Coming Soon!
        </div>
    )
}