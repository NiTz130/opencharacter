export { GET, POST } from "@/server/auth";
export const runtime = "edge";
