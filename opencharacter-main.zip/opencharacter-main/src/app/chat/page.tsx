import Conversation from "@/components/conversation"

export const runtime = "edge"

export default function ChatPage() {
    return (
        <Conversation />
    )
}