import OpenCharacterFreeAccessToPremiumPage from "@/components/free-access-page"

export const runtime = "edge"

export default function Page() {
  return(
    <OpenCharacterFreeAccessToPremiumPage />
  )
}