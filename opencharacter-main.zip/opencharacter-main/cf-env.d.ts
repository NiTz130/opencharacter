declare global {
	namespace NodeJS {
		interface ProcessEnv extends CloudflareEnv {
		}
	}
}

export type {};