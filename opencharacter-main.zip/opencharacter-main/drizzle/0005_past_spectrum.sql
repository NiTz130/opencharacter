ALTER TABLE `character` ADD `temperature` real;--> statement-breakpoint
ALTER TABLE `character` ADD `top_p` real;--> statement-breakpoint
ALTER TABLE `character` ADD `top_k` integer;--> statement-breakpoint
ALTER TABLE `character` ADD `frequency_penalty` real;--> statement-breakpoint
ALTER TABLE `character` ADD `presence_penalty` real;--> statement-breakpoint
ALTER TABLE `character` ADD `repetition_penalty` real;--> statement-breakpoint
ALTER TABLE `character` ADD `min_p` real;--> statement-breakpoint
ALTER TABLE `character` ADD `top_a` real;--> statement-breakpoint
ALTER TABLE `character` ADD `max_tokens` integer;